package com.suncorp.app;

import com.suncorp.app.entities.Account;
import com.suncorp.app.entities.AccountBO;
import com.suncorp.app.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import java.util.Date;

@SpringBootApplication
public class SuncorpapplicationApplication {

	@Autowired
	AccountService accountService;

	public static void main(String[] args) {
		System.out.println("main");
		SpringApplication.run(SuncorpapplicationApplication.class, args);
	}

}

@Component
class DemoCommandLineRunner implements CommandLineRunner{

	@Autowired
	AccountService accountService;

	@Override
	public void run(String... strings) throws Exception {
		System.out.println("We are in run method");
		insertDummyRecords();
		printAccountDetails();
	}

	private void insertDummyRecords(){
		System.out.println("We are in insertDummyRecords method");
		Account account1 =new Account("Sainath","Shinde",new Date(),new Date(),"Saving",1000);
		Account account2 =new Account("Baba","Chavan",new Date(),new Date(),"Deposit",2000);
		//AccountService accountService =new AccountService();

		accountService.createAccount(account1);
		accountService.createAccount(account2);

		//accountService.depositFund(1,100);

	}

	private void printAccountDetails(){
		System.out.println("We are in insertDummyRecords method");
		Iterable<AccountBO>  accountList=accountService.getAllAccounts();
		for (AccountBO account:accountList) {
			System.out.println("Account No::"+account.getAccountId());
			System.out.println("First Name::"+account.getFirstName());
			System.out.println("Last Name::"+account.getLastName());
			System.out.println("Balance::"+account.getBalance());
		}
	}
}
