package com.suncorp.app.controller;

import com.suncorp.app.entities.Account;
import com.suncorp.app.entities.AccountBO;
import com.suncorp.app.entities.AccountTransactionBO;
import com.suncorp.app.service.AccountService;
import com.suncorp.app.service.AccountTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by u217635 on 27/06/2019.
 */
@RestController
@RequestMapping(value="/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountTransactionService accountTransactionService;

    @RequestMapping(value="/create",method= RequestMethod.POST)
    public ResponseEntity<Object> createAccount(@RequestBody Account account){
          accountService.createAccount(account);
          return new ResponseEntity<Object>("Account is Created Succesfully", HttpStatus.CREATED);
    }

    @GetMapping(value="/account/{accountId}")
    public AccountBO getAccountById(@PathVariable("accountId") Integer accountId){
        return accountService.getAccountById(accountId);
    }

    @GetMapping(value="/allaccounts")
    public Iterable<AccountBO> getAllAccounts(){
        return accountService.getAllAccounts();
    }

    @DeleteMapping(value="/account/{accountId}")
    public ResponseEntity<Object> deleteAccount(@PathVariable("accountId") Integer accountId){
        accountService.deleteAccount(accountId);
        return new ResponseEntity<Object>("Account is Deleted Succesfully", HttpStatus.OK);
    }

    @PutMapping(value="/account/{accountId}/{accountType}")
    public ResponseEntity<Object> updateAccount(@PathVariable("accountId") Integer accountId,
                                 @PathVariable("accountType") String accountType){

        accountService.updateAccountType(accountId,accountType);
        return new ResponseEntity<Object>("Account is updated Succesfully", HttpStatus.OK);
    }

    @PutMapping(value="/account/{accountId}/deposit/{amount}")
    public ResponseEntity<Object> depositFund(@PathVariable("accountId") Integer accountId,
                            @PathVariable("amount") Integer amount){
       Integer avalibaleBalance = accountService.depositFund(accountId,amount);
       return new ResponseEntity<Object>("Amount Rs"+ amount +" is deposited Succesfully.Total Balance is Rs " + avalibaleBalance, HttpStatus.OK);
    }

    @PutMapping(value="/account/{accountId}/withdraw/{amount}")
    public ResponseEntity<Object>  withdrawFund(@PathVariable("accountId") Integer accountId,
                                                @PathVariable("amount") Integer amount){
        Integer avalibaleBalance = accountService.withdrawFund(accountId,amount);
        return new ResponseEntity<Object>("Amount Rs"+ amount +"is withdrwal Succesfully.Total Balance is Rs " + avalibaleBalance, HttpStatus.OK);
    }

    @PutMapping(value="/account/{fromAccountId}/transfer/{toAccountId}/amount/{transferAmount}")
    public ResponseEntity<Object> transferAmount(@PathVariable("fromAccountId") Integer fromAccountId,
                                                 @PathVariable("toAccountId") Integer toAccountId,
                                                 @PathVariable("transferAmount") Integer transferAmount){

        accountService.transferAmount(fromAccountId,toAccountId,transferAmount);
        return new ResponseEntity<Object>("Amount Rs "+ transferAmount +"is transfered Succesfully.", HttpStatus.OK);
    }

    @GetMapping(value="/transactions/{accountId}")
    public Iterable<AccountTransactionBO> getTransactionsByAccountId(@PathVariable("accountId") Integer accountId){
       return accountService.getTransactionsByAccountId(accountId);

    }

}
