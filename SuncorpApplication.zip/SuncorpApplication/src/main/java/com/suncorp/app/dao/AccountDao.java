package com.suncorp.app.dao;

import com.suncorp.app.entities.Account;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by u217635 on 27/06/2019.
 */
@Repository
public interface AccountDao extends CrudRepository<Account,Integer> {

}
