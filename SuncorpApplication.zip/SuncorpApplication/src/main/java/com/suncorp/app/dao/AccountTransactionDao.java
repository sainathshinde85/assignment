package com.suncorp.app.dao;

import com.suncorp.app.entities.AccountTransaction;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by u217635 on 27/06/2019.
 */
@Repository
public interface AccountTransactionDao extends CrudRepository<AccountTransaction,Integer> {

}
