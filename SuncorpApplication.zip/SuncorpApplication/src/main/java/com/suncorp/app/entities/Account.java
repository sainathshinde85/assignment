package com.suncorp.app.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by u217635 on 27/06/2019.
 */
@Entity
@Table(name = "Account")
public class Account implements Serializable{

    private static final long serialVersionUID =1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="account_id")
    private Integer accountId;
    private String firstName;
    private String lastName;

    private Date dateOfBirth;
    private Date accountCreationDate;
    private String accountType;
    private Integer balance;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "account")
   // @JoinColumn(name = "accountId")
    private List<AccountTransaction> transactionList;

    public Account(){
        super();
    }

    public Account(String firstName, String lastName, Date dateOfBirth, Date accountCreationDate, String accountType,Integer balance) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.accountCreationDate = accountCreationDate;
        this.accountType = accountType;
        this.balance=balance;
    }

    public Account(Integer accountId,String firstName, String lastName, Date dateOfBirth, Date accountCreationDate, String accountType,Integer balance) {
        this.accountId=accountId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.accountCreationDate = accountCreationDate;
        this.accountType = accountType;
        this.balance=balance;
    }

    public Account(Integer accountId,String firstName, String lastName, Date dateOfBirth, Date accountCreationDate, String accountType,Integer balance,List<AccountTransaction> transactionList) {
        this.accountId=accountId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.accountCreationDate = accountCreationDate;
        this.accountType = accountType;
        this.balance=balance;
        this.transactionList=transactionList;
    }


    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Date getAccountCreationDate() {
        return accountCreationDate;
    }

    public void setAccountCreationDate(Date accountCreationDate) {
        this.accountCreationDate = accountCreationDate;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public List<AccountTransaction> getTransactionList() {
        return transactionList;
    }

    public void setTransactionList(List<AccountTransaction> transactionList) {
        this.transactionList = transactionList;
    }



}
