package com.suncorp.app.entities;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by u217635 on 28/06/2019.
 */
@Entity
@Table(name = "AccountTransaction")
public class AccountTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer accountTrId;
    private String  transactionType;
    private Integer amount;

    private Integer closingBalance;
    private Date     transctionDate;

    @ManyToOne()
    @JoinColumn(name="account_id",nullable = false)
    private Account account;

    public AccountTransaction(){

    }

    public AccountTransaction(String transactionType, Integer amount, Integer closingBalance, Date transctionDate, Account account) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.closingBalance = closingBalance;
        this.transctionDate = transctionDate;
        this.account = account;
    }

    public AccountTransaction(String transactionType, Integer amount, Integer closingBalance, Date transctionDate) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.closingBalance = closingBalance;
        this.transctionDate = transctionDate;
    }

    public Integer getAccountTrId() {
        return accountTrId;
    }

    public void setAccountTrId(Integer accountTrId) {
        this.accountTrId = accountTrId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getClosingBalance() {
        return closingBalance;
    }

    public void setClosingBalance(Integer closingBalance) {
        this.closingBalance = closingBalance;
    }

    public Date getTransctionDate() {
        return transctionDate;
    }

    public void setTransctionDate(Date transctionDate) {
        this.transctionDate = transctionDate;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }




}
