package com.suncorp.app.entities;

import java.util.Date;

/**
 * Created by u217635 on 28/06/2019.
 */

public class AccountTransactionBO {

    private Integer accountTrId;
    private String  transactionType;
    private Integer amount;

    private Integer closingBalance;
    private Date     transctionDate;



    private Integer accountId;



    public AccountTransactionBO(){

    }
    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }
    public Integer getAccountTrId() {
        return accountTrId;
    }

    public void setAccountTrId(Integer accountTrId) {
        this.accountTrId = accountTrId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getClosingBalance() {
        return closingBalance;
    }

    public void setClosingBalance(Integer closingBalance) {
        this.closingBalance = closingBalance;
    }

    public Date getTransctionDate() {
        return transctionDate;
    }

    public void setTransctionDate(Date transctionDate) {
        this.transctionDate = transctionDate;
    }






}
