package com.suncorp.app.service;

import com.suncorp.app.dao.AccountDao;
import com.suncorp.app.dao.AccountTransactionDao;
import com.suncorp.app.entities.Account;
import com.suncorp.app.entities.AccountBO;
import com.suncorp.app.entities.AccountTransaction;
import com.suncorp.app.entities.AccountTransactionBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by u217635 on 27/06/2019.
 */
@Service
public class AccountService {
    @Autowired
    private AccountDao accountDao;

    @Autowired
    private AccountTransactionDao accountTransactionDao;

    /**
     * This method is for to create Account
     * @param account
     * @return
     */
    public void createAccount(Account account){
        accountDao.save(account);
    }

    /**
     * This method is for get Account by id
     * @param accountId
     * @return
     */
    public AccountBO getAccountById(Integer accountId){
        Account account = accountDao.findById(accountId).get();
        AccountBO acc = mapto(account);
        return acc;
    }

    private AccountBO mapto(Account account) {
        AccountBO accountBO = new AccountBO();
        accountBO.setAccountId(account.getAccountId());
        accountBO.setFirstName(account.getFirstName());
        accountBO.setLastName(account.getLastName());
        accountBO.setDateOfBirth(account.getDateOfBirth());
        accountBO.setAccountCreationDate(account.getAccountCreationDate());
        accountBO.setBalance(account.getBalance());
        accountBO.setAccountType(account.getAccountType());

        return accountBO;
    }

    /**
     * This method is for to get all accounts
     * @return
     */
    public Iterable<AccountBO> getAllAccounts(){
        Iterable<Account> list =accountDao.findAll();
        Iterable<AccountBO> accountBOList= mapToAccountBOList(list);
        return accountBOList;
    }
    private List<AccountBO> mapToAccountBOList(Iterable<Account> list){
        List<AccountBO> accountBOList =new ArrayList<AccountBO>();
        for (   Account account :   list     ) {
            AccountBO accountBO = new AccountBO();
            accountBO.setAccountId(account.getAccountId());
            accountBO.setFirstName(account.getFirstName());
            accountBO.setLastName(account.getLastName());
            accountBO.setDateOfBirth(account.getDateOfBirth());
            accountBO.setAccountCreationDate(account.getAccountCreationDate());
            accountBO.setBalance(account.getBalance());
            accountBO.setAccountType(account.getAccountType());
            accountBOList.add(accountBO);
        }
        return accountBOList;
    }

    /**
     * This method is for to delete account
     * @param accountId
     */
    public void deleteAccount(Integer accountId){
        accountDao.deleteById(accountId);

    }

    /**
     * This method ts for update account type
     * @param accountId
     * @param accountYpe
     * @return
     */
    public void updateAccountType(Integer accountId,String accountYpe){
        Account accountFromDb = accountDao.findById(accountId).get();
        accountFromDb.setAccountType(accountYpe);
        accountDao.save(accountFromDb);

    }

    /**
     * This method is  for deposit fund
     * @param accountId
     * @param amount
     * @return
     */
    public Integer depositFund(Integer accountId,Integer amount){
        Account accountFromDB = accountDao.findById(accountId).get();
        Integer availableBlance= accountFromDB.getBalance();
        availableBlance =availableBlance+amount;
        accountFromDB.setBalance(availableBlance);
        //Create Child table record
        AccountTransaction transaction=new AccountTransaction("Deposit",amount,availableBlance,new Date(),accountFromDB);
        transaction.setAccount(accountFromDB);
        accountFromDB.setTransactionList(new ArrayList<AccountTransaction>());
        accountFromDB.getTransactionList().add(transaction);


        accountDao.save(accountFromDB);
        //accountTransactionDao.save(transaction);

        //Here you need to create a record  in AccountTransaction table Which we will create after some time
        return availableBlance;

    }

    /**
     * This method is for withdra fund from account
     * @param acountId
     * @param amount
     * @return
     */
    public Integer withdrawFund(Integer acountId,Integer amount){
        Account accountFromDB = accountDao.findById(acountId).get();
        Integer availableBlance= accountFromDB.getBalance();
        if(availableBlance > 0  && amount < availableBlance){
            availableBlance =availableBlance-amount;
            accountFromDB.setBalance(availableBlance);

            //Create Child table record
            AccountTransaction transaction=new AccountTransaction("Withdraw",amount,availableBlance,new Date(),accountFromDB);
            transaction.setAccount(accountFromDB);
            accountFromDB.setTransactionList(new ArrayList<AccountTransaction>());
            accountFromDB.getTransactionList().add(transaction);
            accountDao.save(accountFromDB);

            //Here you need to create a record  in AccountTransaction table Which we will create after some time
            //accountTransactionDao.save(new AccountTransaction("Withdraw",amount,availableBlance,new Date(),accountFromDB));
        }else{
            //TODO :Raise a exception insufficent balance You can not withdraw fund
        }

        return availableBlance;

        //
    }

    /***
     * This method is used to transfer funds from once account to another account
     * @param fromAccountId
     * @param toAccountId
     * @param amount
     */
    public void transferAmount(Integer fromAccountId,Integer toAccountId,Integer amount){
        Account fromAccount = accountDao.findById(fromAccountId).get();
        Account toAccount = accountDao.findById(toAccountId).get();
        Integer availableBlance= fromAccount.getBalance();
        Integer toAccountBalance=0;
        if(availableBlance > 0  && amount < availableBlance){
            //Withdraw from from account
            availableBlance =availableBlance-amount;
            fromAccount.setBalance(availableBlance);
            accountDao.save(fromAccount);

            // deposit into to account
            toAccountBalance= toAccount.getBalance()+amount;
            toAccount.setBalance(toAccountBalance);
            accountDao.save(toAccount);
        }else{
            //Raise a exception insufficent balance You can not transfer fund
        }

         //TODO : I am not using here transction manager so taking only positive senerio
    }

    public  List<AccountTransactionBO> getTransactionsByAccountId(Integer accountId){

        List<AccountTransaction> listOfTransactions;
        List<AccountTransactionBO> listOfAccountTransactionBO =new ArrayList<AccountTransactionBO>();
       Account account=accountDao.findById(accountId).get();
       if(account!=null){
           listOfTransactions= account.getTransactionList();
           if(listOfTransactions!=null){
               for (AccountTransaction accountTransaction: listOfTransactions   ) {
                   AccountTransactionBO accountTransctionBO =new AccountTransactionBO();
                   accountTransctionBO.setAccountId(accountTransaction.getAccount().getAccountId());
                   accountTransctionBO.setTransactionType(accountTransaction.getTransactionType());
                   accountTransctionBO.setAmount(accountTransaction.getAmount());
                   accountTransctionBO.setClosingBalance(accountTransaction.getClosingBalance());
                   accountTransctionBO.setAccountTrId(accountTransaction.getAccountTrId());
                   accountTransctionBO.setTransctionDate(accountTransaction.getTransctionDate());
                   listOfAccountTransactionBO.add(accountTransctionBO);
               }
           }
       }
       return listOfAccountTransactionBO;
    }
}
