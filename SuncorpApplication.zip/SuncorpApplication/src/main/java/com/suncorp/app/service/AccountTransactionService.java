package com.suncorp.app.service;

import com.suncorp.app.dao.AccountDao;
import com.suncorp.app.dao.AccountTransactionDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by u217635 on 28/06/2019.
 */
@Service
public class AccountTransactionService {

    @Autowired
    private AccountDao accountDao;
    @Autowired
    private AccountTransactionDao accountTransactionDao;




}
